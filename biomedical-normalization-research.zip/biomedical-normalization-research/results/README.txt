Generated output files will be saved in this folder after running main.py.
